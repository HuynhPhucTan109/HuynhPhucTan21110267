import Header from "./Header"
import Footer from "./Footer"
import Content from "./Content"



export{
    Header,
    Footer,
    Content,
}